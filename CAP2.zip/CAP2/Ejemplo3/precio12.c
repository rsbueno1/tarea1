#include <stdio.h>
/* Incremento de precio.
El programa, al recibir como dato el precio de un producto importado,
incrementa 11% el mismo si �ste es inferior a $1,500.

PRE y NPR: variable de tipo real. */
void main(void)
{
    float PRE, NPR;  //Declaracion de variables
    printf("ingrese el precio del productojj: "); // Se presenta en pantalla lo que esta dentro del parentesis
    scanf("%f", &PRE);


    if (PRE < 1500)  //Se aplica el condicional if para establecer el porcentaje
        {
          NPR = PRE * 1.11;
          printf("\nNuevo precio: %7.2f", NPR);
        }
}
