#include <stdio.h>
/* incremento de precio.
El programa, al recibir como dato el precio de un producto, incrementa al
mismo 11% si es menor a 1500$ y 8% en caso contrario (mayor o igual).

PRE y NPR: variable de tipo real. */
void main(void)
{
    float PRE, NPR;  //Declaracion de variables
    printf("ingrese el precio del producto: "); // Se presenta en pantalla lo que esta dentro del parentesis
    scanf("%f", &PRE);


    if (PRE < 1500)  //Se aplica el condicional if para establecer el porcentaje
        {
          NPR = PRE * 1.11;
        }
        else if(PRE >= 1500)
        {
          NPR= PRE*1.08;
          printf("\nNuevo precio: %8.2f", NPR);
        }
}
