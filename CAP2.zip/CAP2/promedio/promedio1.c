/* Promedio curso.
El programa, al recibir como dato el promedio de un alumno en un curso
universitario, escribe aprobado si su promedio es mayor o igual a 6, o
reprobado en caso contrario.

PRO: variable de tipo real. */

void main(void)
{
float PRO;
printf("ingrese el promedio del alumno: "); //Solicita al usuario el dato(Promedio) del alumno
scanf("%f", &PRO);
if (PRO >= 6) // Se aplica el condicional if para establer el rango de promedio para aprobar o reprobar
printf("\nAprobado");

else
    printf("\nReprobado");
}
